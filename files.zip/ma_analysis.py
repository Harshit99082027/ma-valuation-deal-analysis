"""
Global M&A Industry Analysis — Python Script
Investment Banking Research Project | 2025–2026
Author: [Your Name]

This script performs:
1. M&A deal volume & value trend analysis
2. Sector-level deal activity visualization
3. DCF sensitivity analysis (WACC vs Terminal Growth Rate)
4. Comparable companies valuation multiples analysis
5. Deal screening composite score ranking

Libraries: pandas, matplotlib, numpy
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from matplotlib.colors import LinearSegmentedColormap
import warnings
warnings.filterwarnings("ignore")

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "axes.spines.top": False,
    "axes.spines.right": False,
    "figure.facecolor": "white",
    "axes.facecolor": "#F8F9FA",
    "axes.grid": True,
    "grid.color": "#E0E0E0",
    "grid.linewidth": 0.8,
})

DARK_BLUE  = "#1B4F8A"
MID_BLUE   = "#2E75B6"
LIGHT_BLUE = "#9DC3E6"
GOLD       = "#C7A535"
GREEN      = "#217346"
RED        = "#C0392B"
GRAY       = "#666666"

# ─────────────────────────────────────────────────────
# 1. GLOBAL M&A MARKET DATA
# ─────────────────────────────────────────────────────

deal_data = pd.DataFrame({
    "Year":       [2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025],
    "Value_tn":   [3.5,  3.2,  3.2,  5.9,  3.6,  2.9,  3.1,  3.8],
    "Volume_k":   [41.2, 40.1, 39.8, 52.1, 44.3, 39.6, 40.8, 42.5],
    "Megadeals":  [72,   65,   52,   130,  74,   58,   68,   89],
    "PE_Pct":     [16,   17,   16,   22,   19,   16,   18,   21],
    "Tech_Pct":   [22,   24,   24,   29,   26,   25,   28,   31],
    "CrossBorder":[21,   22,   20,   24,   21,   19,   22,   26],
})

# ─────────────────────────────────────────────────────
# 2. SECTOR DATA
# ─────────────────────────────────────────────────────

sector_data = pd.DataFrame({
    "Sector": [
        "Technology & AI", "Banking & FinServ", "Manufacturing",
        "Healthcare/Pharma", "Energy & Utilities", "Wealth Management", "Real Estate"
    ],
    "Megadeals_2025": [26, 13, 11, 8, 7, 6, 5],
    "Value_2025_bn":  [1180, 490, 380, 220, 180, 113, 95],
    "YoY_Growth":     [0.28, 0.15, 0.09, -0.12, 0.22, 0.35, -0.05],
    "Outlook_Score":  [9.2, 7.8, 6.5, 6.0, 7.5, 7.9, 5.2],
})

# ─────────────────────────────────────────────────────
# 3. COMPARABLE COMPANIES DATA
# ─────────────────────────────────────────────────────

comps_data = pd.DataFrame({
    "Company":       ["Alpha", "Beta", "Gamma", "Delta", "Epsilon", "Zeta", "Eta", "Theta"],
    "Market_Cap_mm": [18500, 45000, 9200, 6800, 31000, 4100, 22000, 8400],
    "Net_Debt_mm":   [1200, -800, 600, 300, -2000, 800, 2400, 150],
    "Revenue_mm":    [820, 2100, 410, 290, 1400, 180, 990, 370],
    "EBITDA_mm":     [205, 630, 82, 58, 280, 27, 248, 74],
    "Growth_Rate":   [0.22, 0.18, 0.25, 0.30, 0.38, 0.20, 0.14, 0.19],
})
comps_data["EV_mm"] = comps_data["Market_Cap_mm"] + comps_data["Net_Debt_mm"]
comps_data["EBITDA_Margin"] = comps_data["EBITDA_mm"] / comps_data["Revenue_mm"]
comps_data["EV_Revenue"]    = comps_data["EV_mm"] / comps_data["Revenue_mm"]
comps_data["EV_EBITDA"]     = comps_data["EV_mm"] / comps_data["EBITDA_mm"]

# ─────────────────────────────────────────────────────
# 4. DCF SENSITIVITY ANALYSIS
# ─────────────────────────────────────────────────────

def dcf_enterprise_value(
    base_revenue=500, growth_rates=(0.18, 0.18, 0.18, 0.12, 0.12),
    ebitda_margin=0.25, da_pct=0.05, capex_pct=0.06, nwc_pct=0.02,
    tax_rate=0.21, wacc=0.10, terminal_growth=0.03
):
    revenues, fcfs = [], []
    rev = base_revenue
    for g in growth_rates:
        rev = rev * (1 + g)
        revenues.append(rev)
        ebitda = rev * ebitda_margin
        ebit   = ebitda - rev * da_pct
        nopat  = ebit * (1 - tax_rate)
        fcf    = nopat + rev * da_pct - rev * capex_pct - rev * nwc_pct
        fcfs.append(fcf)

    discount_factors = [(1 / (1 + wacc) ** (t + 1)) for t in range(5)]
    pv_fcfs = sum(f * d for f, d in zip(fcfs, discount_factors))

    terminal_ebitda = revenues[-1] * ebitda_margin
    tv = (fcfs[-1] * (1 + terminal_growth)) / (wacc - terminal_growth)
    pv_tv = tv * discount_factors[-1]

    return pv_fcfs + pv_tv

# Build sensitivity table
waccs  = [0.08, 0.09, 0.10, 0.11, 0.12]
tg_rates = [0.02, 0.025, 0.03, 0.035, 0.04]
sensitivity = pd.DataFrame(
    {f"{tg*100:.1f}%": [dcf_enterprise_value(wacc=w, terminal_growth=tg) for w in waccs]
     for tg in tg_rates},
    index=[f"{w*100:.0f}%" for w in waccs]
)
sensitivity.index.name = "WACC \\ TGR"

# ─────────────────────────────────────────────────────
# 5. DEAL SCREENING
# ─────────────────────────────────────────────────────

screening_data = pd.DataFrame({
    "Target":          ["Alpha", "Beta", "Gamma", "Delta", "Epsilon", "Zeta", "Eta"],
    "Sector":          ["AI Infra", "V-SaaS", "Data/Analytics", "Fintech", "Cybersec", "Cloud Infra", "HR Tech"],
    "Est_EV_mm":       [2800, 650, 1400, 3200, 920, 1100, 480],
    "Revenue_mm":      [180, 95, 210, 380, 140, 160, 72],
    "Growth_Rate":     [0.35, 0.22, 0.18, 0.15, 0.28, 0.20, 0.12],
    "Strategic_Fit":   [5, 4, 4, 3, 5, 3, 2],
    "Fin_Strength":    [4, 4, 3, 5, 3, 4, 4],
    "Integration_Risk":[3, 2, 3, 4, 2, 3, 2],
})
screening_data["Composite"] = (
    screening_data["Strategic_Fit"] * 0.40 +
    screening_data["Fin_Strength"]  * 0.35 +
    (5 - screening_data["Integration_Risk"]) * 0.25
)
screening_data["Recommendation"] = screening_data["Composite"].apply(
    lambda x: "Advance to DD" if x >= 3.5 else ("Monitor" if x >= 2.8 else "Pass")
)
screening_data = screening_data.sort_values("Composite", ascending=False)

# ─────────────────────────────────────────────────────
# PLOTTING — Create a multi-panel figure
# ─────────────────────────────────────────────────────

fig = plt.figure(figsize=(20, 24))
fig.suptitle("Global M&A Industry Analysis — 2025–2026\nInvestment Banking Research Project",
             fontsize=18, fontweight="bold", color=DARK_BLUE, y=0.98)

# Subtitle
fig.text(0.5, 0.965, "Author: [Your Name]  |  Data Sources: Morgan Stanley, PwC, McKinsey, Goldman Sachs, J.P. Morgan (2026)",
         ha="center", fontsize=9, color=GRAY)

# ─── Panel 1: M&A Deal Value Trend ───
ax1 = fig.add_subplot(4, 3, 1)
bars = ax1.bar(deal_data["Year"], deal_data["Value_tn"],
               color=[GOLD if y == 2025 else MID_BLUE for y in deal_data["Year"]], width=0.6, edgecolor="white")
ax1.set_title("Global M&A Deal Value ($tn)", fontweight="bold", color=DARK_BLUE, pad=8)
ax1.set_ylabel("Deal Value ($ Trillion)", fontsize=9)
ax1.set_ylim(0, 7)
for bar in bars:
    ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.05,
             f"${bar.get_height():.1f}T", ha="center", va="bottom", fontsize=8, color=DARK_BLUE)
ax1.set_facecolor("#F8F9FA")

# ─── Panel 2: Megadeals Count ───
ax2 = fig.add_subplot(4, 3, 2)
ax2.plot(deal_data["Year"], deal_data["Megadeals"], "o-", color=GOLD, linewidth=2.5, markersize=7)
ax2.fill_between(deal_data["Year"], deal_data["Megadeals"], alpha=0.15, color=GOLD)
ax2.set_title("Megadeal Count (>$5bn)", fontweight="bold", color=DARK_BLUE, pad=8)
ax2.set_ylabel("Number of Megadeals", fontsize=9)
for x, y in zip(deal_data["Year"], deal_data["Megadeals"]):
    ax2.annotate(str(y), (x, y), textcoords="offset points", xytext=(0, 8),
                 ha="center", fontsize=8, color=DARK_BLUE)

# ─── Panel 3: PE & Tech Participation ───
ax3 = fig.add_subplot(4, 3, 3)
ax3.plot(deal_data["Year"], deal_data["Tech_Pct"], "o-", color=MID_BLUE, label="Tech %", linewidth=2.5, markersize=6)
ax3.plot(deal_data["Year"], deal_data["PE_Pct"], "s--", color=GOLD, label="PE %", linewidth=2.5, markersize=6)
ax3.plot(deal_data["Year"], deal_data["CrossBorder"], "^:", color=GREEN, label="Cross-Border %", linewidth=2, markersize=6)
ax3.set_title("Tech, PE & Cross-Border as % of Deals", fontweight="bold", color=DARK_BLUE, pad=8)
ax3.set_ylabel("% of Total Deal Value", fontsize=9)
ax3.legend(fontsize=8, loc="upper left")
ax3.yaxis.set_major_formatter(mticker.PercentFormatter())

# ─── Panel 4: Sector Deal Value ───
ax4 = fig.add_subplot(4, 3, 4)
colors_sector = [DARK_BLUE, MID_BLUE, LIGHT_BLUE, GOLD, GREEN, "#8E44AD", "#C0392B"]
bars4 = ax4.barh(sector_data["Sector"], sector_data["Value_2025_bn"],
                 color=colors_sector, edgecolor="white")
ax4.set_title("2025 M&A Deal Value by Sector ($bn)", fontweight="bold", color=DARK_BLUE, pad=8)
ax4.set_xlabel("Deal Value ($bn)", fontsize=9)
for bar in bars4:
    ax4.text(bar.get_width() + 10, bar.get_y() + bar.get_height()/2,
             f"${bar.get_width():.0f}bn", va="center", fontsize=8, color=DARK_BLUE)

# ─── Panel 5: Sector YoY Growth ───
ax5 = fig.add_subplot(4, 3, 5)
yoy_colors = [GREEN if v >= 0 else RED for v in sector_data["YoY_Growth"]]
bars5 = ax5.barh(sector_data["Sector"], sector_data["YoY_Growth"] * 100,
                 color=yoy_colors, edgecolor="white")
ax5.axvline(0, color="black", linewidth=0.8)
ax5.set_title("2025 Deal Value YoY Growth (%)", fontweight="bold", color=DARK_BLUE, pad=8)
ax5.set_xlabel("Year-on-Year Change (%)", fontsize=9)
ax5.xaxis.set_major_formatter(mticker.PercentFormatter())

# ─── Panel 6: Sector Outlook Score ───
ax6 = fig.add_subplot(4, 3, 6)
cmap = plt.cm.RdYlGn
norm = plt.Normalize(vmin=4, vmax=10)
colors_out = [cmap(norm(v)) for v in sector_data["Outlook_Score"]]
bars6 = ax6.bar(sector_data["Sector"], sector_data["Outlook_Score"],
                color=colors_out, edgecolor="white")
ax6.set_title("2026 Sector Outlook Score (1–10)", fontweight="bold", color=DARK_BLUE, pad=8)
ax6.set_ylabel("Score", fontsize=9)
ax6.set_ylim(0, 11)
ax6.set_xticklabels(sector_data["Sector"], rotation=35, ha="right", fontsize=7)
for bar in bars6:
    ax6.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.15,
             f"{bar.get_height():.1f}", ha="center", va="bottom", fontsize=8, color="black")

# ─── Panel 7: Comps EV/EBITDA vs Growth ───
ax7 = fig.add_subplot(4, 3, 7)
sc = ax7.scatter(comps_data["Growth_Rate"] * 100, comps_data["EV_EBITDA"],
                  c=comps_data["EV_Revenue"], cmap="Blues", s=120, edgecolors=DARK_BLUE, linewidths=1)
for _, row in comps_data.iterrows():
    ax7.annotate(row["Company"], (row["Growth_Rate"]*100, row["EV_EBITDA"]),
                 textcoords="offset points", xytext=(5, 5), fontsize=8)
plt.colorbar(sc, ax=ax7, label="EV/Revenue")
ax7.set_title("EV/EBITDA vs Revenue Growth Rate", fontweight="bold", color=DARK_BLUE, pad=8)
ax7.set_xlabel("LTM Revenue Growth (%)", fontsize=9)
ax7.set_ylabel("EV/EBITDA Multiple", fontsize=9)
ax7.xaxis.set_major_formatter(mticker.PercentFormatter())

# ─── Panel 8: DCF Sensitivity Heatmap ───
ax8 = fig.add_subplot(4, 3, 8)
heatmap_data = sensitivity.values.astype(float)
im = ax8.imshow(heatmap_data, cmap="RdYlGn", aspect="auto")
ax8.set_xticks(range(len(sensitivity.columns)))
ax8.set_xticklabels([f"TGR: {c}" for c in sensitivity.columns], fontsize=8, rotation=20, ha="right")
ax8.set_yticks(range(len(sensitivity.index)))
ax8.set_yticklabels([f"WACC: {r}" for r in sensitivity.index], fontsize=8)
ax8.set_title("DCF Enterprise Value Sensitivity ($mm)\nWACC vs Terminal Growth Rate", fontweight="bold", color=DARK_BLUE, pad=8)
for i in range(len(sensitivity.index)):
    for j in range(len(sensitivity.columns)):
        ax8.text(j, i, f"${heatmap_data[i,j]:.0f}", ha="center", va="center", fontsize=7.5, fontweight="bold")
plt.colorbar(im, ax=ax8, label="Enterprise Value ($mm)")

# ─── Panel 9: Deal Screening Ranking ───
ax9 = fig.add_subplot(4, 3, 9)
rec_colors = {
    "Advance to DD": GREEN,
    "Monitor": GOLD,
    "Pass": RED
}
bar_colors = [rec_colors[r] for r in screening_data["Recommendation"]]
bars9 = ax9.barh(screening_data["Target"], screening_data["Composite"],
                  color=bar_colors, edgecolor="white")
ax9.axvline(3.5, color=GREEN, linestyle="--", linewidth=1.5, alpha=0.7, label="Advance Threshold")
ax9.axvline(2.8, color=GOLD, linestyle="--", linewidth=1.5, alpha=0.7, label="Monitor Threshold")
ax9.set_title("M&A Deal Screening — Composite Score", fontweight="bold", color=DARK_BLUE, pad=8)
ax9.set_xlabel("Composite Score (max 5.0)", fontsize=9)
ax9.legend(fontsize=8, loc="lower right")
for bar in bars9:
    ax9.text(bar.get_width() + 0.02, bar.get_y() + bar.get_height()/2,
             f"{bar.get_width():.2f}", va="center", fontsize=8)

# ─── Panel 10-11-12: Summary Statistics Table (spans bottom row) ───
ax10 = fig.add_subplot(4, 1, 4)
ax10.axis("off")
ax10.set_title("Comparable Companies — Valuation Multiple Summary Statistics",
               fontweight="bold", color=DARK_BLUE, fontsize=12, pad=10)

stats_df = pd.DataFrame({
    "Metric": ["EV/Revenue", "EV/EBITDA", "EBITDA Margin", "Rev Growth Rate"],
    "Mean": [
        f"{comps_data['EV_Revenue'].mean():.1f}x",
        f"{comps_data['EV_EBITDA'].mean():.1f}x",
        f"{comps_data['EBITDA_Margin'].mean():.1%}",
        f"{comps_data['Growth_Rate'].mean():.1%}",
    ],
    "Median": [
        f"{comps_data['EV_Revenue'].median():.1f}x",
        f"{comps_data['EV_EBITDA'].median():.1f}x",
        f"{comps_data['EBITDA_Margin'].median():.1%}",
        f"{comps_data['Growth_Rate'].median():.1%}",
    ],
    "25th Pct": [
        f"{comps_data['EV_Revenue'].quantile(0.25):.1f}x",
        f"{comps_data['EV_EBITDA'].quantile(0.25):.1f}x",
        f"{comps_data['EBITDA_Margin'].quantile(0.25):.1%}",
        f"{comps_data['Growth_Rate'].quantile(0.25):.1%}",
    ],
    "75th Pct": [
        f"{comps_data['EV_Revenue'].quantile(0.75):.1f}x",
        f"{comps_data['EV_EBITDA'].quantile(0.75):.1f}x",
        f"{comps_data['EBITDA_Margin'].quantile(0.75):.1%}",
        f"{comps_data['Growth_Rate'].quantile(0.75):.1%}",
    ],
    "Min": [
        f"{comps_data['EV_Revenue'].min():.1f}x",
        f"{comps_data['EV_EBITDA'].min():.1f}x",
        f"{comps_data['EBITDA_Margin'].min():.1%}",
        f"{comps_data['Growth_Rate'].min():.1%}",
    ],
    "Max": [
        f"{comps_data['EV_Revenue'].max():.1f}x",
        f"{comps_data['EV_EBITDA'].max():.1f}x",
        f"{comps_data['EBITDA_Margin'].max():.1%}",
        f"{comps_data['Growth_Rate'].max():.1%}",
    ],
})

table = ax10.table(
    cellText=stats_df.values,
    colLabels=stats_df.columns,
    cellLoc="center",
    loc="center",
    bbox=[0, 0, 1, 0.92]
)
table.auto_set_font_size(False)
table.set_fontsize(10)

for (row, col), cell in table.get_celld().items():
    cell.set_edgecolor("#CCCCCC")
    if row == 0:
        cell.set_facecolor(DARK_BLUE)
        cell.set_text_props(color="white", fontweight="bold")
    elif row % 2 == 0:
        cell.set_facecolor("#F0F4FA")
    else:
        cell.set_facecolor("white")
    if col == 0 and row > 0:
        cell.set_text_props(fontweight="bold", color=DARK_BLUE)

plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig("/home/claude/ma_analysis_charts.png", dpi=150, bbox_inches="tight",
            facecolor="white", edgecolor="none")
print("Charts saved to ma_analysis_charts.png")

# ─────────────────────────────────────────────────────
# PRINT ANALYSIS SUMMARY
# ─────────────────────────────────────────────────────

print("\n" + "="*70)
print("  GLOBAL M&A INDUSTRY ANALYSIS — KEY FINDINGS")
print("="*70)

print("\n📊 MARKET OVERVIEW")
latest = deal_data.iloc[-1]
prior  = deal_data.iloc[-2]
print(f"  2025 Global Deal Value:   ${latest['Value_tn']:.1f}T  ({(latest['Value_tn']-prior['Value_tn'])/prior['Value_tn']*100:+.1f}% YoY)")
print(f"  2025 Megadeals (>$5bn):   {int(latest['Megadeals'])} deals  ({(latest['Megadeals']-prior['Megadeals'])/prior['Megadeals']*100:+.1f}% YoY)")
print(f"  Technology Sector Share:  {latest['Tech_Pct']}% of deal value")
print(f"  PE Contribution:          {latest['PE_Pct']}% of deal value")
print(f"  Cross-Border Share:       {latest['CrossBorder']}%")

print("\n🏆 TOP SECTORS BY 2025 DEAL VALUE")
for _, row in sector_data.sort_values("Value_2025_bn", ascending=False).iterrows():
    trend = "▲" if row["YoY_Growth"] > 0 else "▼"
    print(f"  {trend} {row['Sector']:<25} ${row['Value_2025_bn']:>6.0f}bn  ({row['YoY_Growth']*100:+.0f}% YoY)  Outlook: {row['Outlook_Score']:.1f}/10")

print("\n📈 DCF SENSITIVITY — ENTERPRISE VALUE ($mm)")
print(f"{'WACC \\ TGR':<12}" + "  ".join(f"{c:>10}" for c in sensitivity.columns))
for idx_label, row_vals in sensitivity.iterrows():
    print(f"{idx_label:<12}" + "  ".join(f"${v:>8.0f}" for v in row_vals))

print("\n🔍 M&A DEAL SCREENING RESULTS (Ranked by Composite Score)")
for _, row in screening_data.iterrows():
    icon = "✅" if row["Recommendation"] == "Advance to DD" else ("⚠️ " if row["Recommendation"] == "Monitor" else "❌")
    print(f"  {icon}  {row['Target']:<12} [{row['Sector']:<15}]  Score: {row['Composite']:.2f}  →  {row['Recommendation']}")

print("\n📋 COMPARABLE COMPANIES — VALUATION MULTIPLES SUMMARY")
print(f"  {'Company':<12} {'EV ($mm)':>10} {'Rev ($mm)':>10} {'EBITDA Mgn':>12} {'EV/Rev':>8} {'EV/EBITDA':>11}")
for _, row in comps_data.iterrows():
    print(f"  {row['Company']:<12} {row['EV_mm']:>10,.0f} {row['Revenue_mm']:>10,.0f} {row['EBITDA_Margin']:>11.1%} {row['EV_Revenue']:>7.1f}x {row['EV_EBITDA']:>10.1f}x")

print(f"\n  Median EV/Revenue:  {comps_data['EV_Revenue'].median():.1f}x")
print(f"  Median EV/EBITDA:   {comps_data['EV_EBITDA'].median():.1f}x")
print(f"  Median EBITDA Mgn:  {comps_data['EBITDA_Margin'].median():.1%}")

print("\n" + "="*70)
print("  Analysis complete. Charts saved to: ma_analysis_charts.png")
print("="*70)
