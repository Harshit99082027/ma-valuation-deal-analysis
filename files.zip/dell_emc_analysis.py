"""
Dell / EMC Corporation — M&A Case Study Analysis
$67 Billion Acquisition | Closed September 7, 2016
Investment Banking Research Project

This script produces:
1. Pre-deal financial profile comparison (Dell vs. EMC)
2. Deal valuation analysis: multiples, SOTP, comparable transactions
3. Post-merger revenue & debt performance timeline
4. Integration scorecard visualization
5. Deal financing structure breakdown
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.ticker as mticker
import numpy as np
import warnings
warnings.filterwarnings("ignore")

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "axes.spines.top": False,
    "axes.spines.right": False,
    "figure.facecolor": "white",
    "axes.facecolor": "#F8F9FA",
    "axes.grid": True,
    "grid.color": "#E0E0E0",
    "grid.linewidth": 0.7,
})

DB  = "#1B4F8A"
MB  = "#2E75B6"
LB  = "#9DC3E6"
GOLD= "#C7A535"
GRN = "#217346"
RED = "#C0392B"
GRY = "#666666"
LGY = "#F0F4FA"

# ─────────────────────────────────────────────────────
# DATA
# ─────────────────────────────────────────────────────

# Pre-deal financials (FY2015, $bn)
dell_financials = {
    "Revenue":     54.1,  "Gross Profit":  9.5,  "Operating Income": 2.2,
    "EBITDA":       3.4,  "Net Income":    1.34, "R&D":              1.1,
    "Gross Margin": 0.175,"EBITDA Margin": 0.063,
}
emc_financials = {
    "Revenue":     24.7,  "Gross Profit":  15.0, "Operating Income": 2.8,
    "EBITDA":       5.5,  "Net Income":    2.0,  "R&D":              3.2,
    "Gross Margin": 0.607,"EBITDA Margin": 0.223,
}

# EMC historical revenue ($bn)
emc_years   = [2010, 2011, 2012, 2013, 2014, 2015]
emc_revenue = [17.0, 20.0, 21.7, 23.2, 24.4, 24.7]
emc_ni      = [1.90, 2.51, 2.70, 3.10, 2.65, 2.00]

# Dell Technologies post-merger revenue & debt ($bn)
post_fy     = ["FY2016\n(partial)", "FY2017", "FY2018", "FY2019", "FY2020", "FY2021", "FY2022\n(post-spin)"]
post_rev    = [62.0, 79.0, 78.7, 91.0, 94.0, 94.2, 101.2]
post_debt   = [52.0, 46.0, 44.0, 40.0, 36.0, 29.0, 22.0]
post_ent    = [21.5, 26.0, 27.0, 30.1, 31.5, 32.0, 34.0]  # Enterprise ISG revenue

# SOTP valuation ($bn)
sotp_labels = ["VMware\n(80% stake)", "EMC Info\nInfrastructure", "RSA\nSecurity",
               "Pivotal", "Virtustream", "Net Debt\nAdjust."]
sotp_values = [40.0, 18.5, 2.5, 1.5, 1.2, -0.2]
sotp_colors = [DB, MB, LB, GOLD, GRN, RED]

# Deal financing breakdown ($bn)
fin_labels  = ["New Senior Debt\n(Term + Notes)", "EMC Cash\nReserves", "VMware\nTracking Stock",
               "Dell/Silver Lake\nEquity", "Other/Adj."]
fin_values  = [45.9, 9.0, 9.0, 4.4, 1.3]
fin_colors  = [RED, GOLD, GRN, MB, GRY]

# Comparable precedents
prec_names   = ["Dell/EMC\n(2016)", "Avago/Broadcom\n(2016)", "MSFT/LinkedIn\n(2016)",
                "IBM/Red Hat\n(2019)", "HP/Compaq\n(2002)", "Oracle/Sun\n(2010)"]
prec_ev_rev  = [2.7, 5.4, 9.0, 10.0, 0.7, 0.6]
prec_premium = [28, 28, 50, 63, 19, 44]
prec_sizes   = [67, 37, 26.2, 34.0, 25.0, 7.4]  # deal size for bubble size

# Integration scorecard
score_dims   = ["Strategic Transform.", "Revenue Synergies", "Cost Synergies",
                "Debt Management", "VMware Value Capture", "Ent. Storage Market",
                "Cultural Integration", "Cloud Transition"]
score_vals   = [5, 4, 5, 4, 5, 3, 4, 3]
score_colors = [GRN if v>=4 else GOLD if v==3 else RED for v in score_vals]

# ─────────────────────────────────────────────────────
# FIGURE
# ─────────────────────────────────────────────────────

fig = plt.figure(figsize=(22, 26))
fig.patch.set_facecolor("white")

fig.suptitle("Dell / EMC Corporation — M&A Case Study Analysis\n$67 Billion Acquisition (2016) | Largest Technology Deal in History",
             fontsize=17, fontweight="bold", color=DB, y=0.98)
fig.text(0.5, 0.965, "Author: [Your Name]  |  Investment Banking Research Project  |  Sources: Dell 10-K, EMC 10-K, Dell Technologies Press Releases, M&A Watch, Network Computing",
         ha="center", fontsize=9, color=GRY)

# ─── Panel 1: Pre-Deal Revenue Comparison ───
ax1 = fig.add_subplot(4, 3, 1)
metrics = ["Revenue", "Gross Profit", "EBITDA", "R&D"]
dell_vals = [dell_financials[m] for m in metrics]
emc_vals  = [emc_financials[m] for m in metrics]
x = np.arange(len(metrics))
w = 0.35
b1 = ax1.bar(x - w/2, dell_vals, w, color=MB, label="Dell", edgecolor="white", linewidth=0.8)
b2 = ax1.bar(x + w/2, emc_vals,  w, color=GOLD, label="EMC", edgecolor="white", linewidth=0.8)
ax1.set_xticks(x); ax1.set_xticklabels(metrics, fontsize=8)
ax1.set_title("Pre-Deal P&L Comparison (FY2015, $bn)", fontweight="bold", color=DB, pad=8)
ax1.set_ylabel("$bn", fontsize=9)
ax1.legend(fontsize=8)
for bar in list(b1)+list(b2):
    ax1.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.3,
             f"${bar.get_height():.1f}", ha="center", va="bottom", fontsize=7.5, color=DB)

# ─── Panel 2: Margin Comparison ───
ax2 = fig.add_subplot(4, 3, 2)
margin_labels = ["Gross Margin", "EBITDA Margin"]
dell_margins  = [dell_financials["Gross Margin"]*100, dell_financials["EBITDA Margin"]*100]
emc_margins   = [emc_financials["Gross Margin"]*100, emc_financials["EBITDA Margin"]*100]
x2 = np.arange(len(margin_labels))
ax2.bar(x2-0.2, dell_margins, 0.35, color=MB, label="Dell", edgecolor="white")
ax2.bar(x2+0.2, emc_margins,  0.35, color=GOLD, label="EMC", edgecolor="white")
ax2.set_xticks(x2); ax2.set_xticklabels(margin_labels, fontsize=9)
ax2.set_title("Margin Profile Comparison (FY2015)", fontweight="bold", color=DB, pad=8)
ax2.set_ylabel("Margin (%)", fontsize=9)
ax2.yaxis.set_major_formatter(mticker.PercentFormatter())
ax2.legend(fontsize=8)
for container in ax2.containers:
    ax2.bar_label(container, fmt="%.1f%%", fontsize=8, padding=2)
# Annotation
ax2.annotate("EMC\u2019s software-heavy\nbusiness commands\nhigher margins",
             xy=(0.5, 22), xytext=(0.1, 45), fontsize=7, color=GRY,
             arrowprops=dict(arrowstyle="-", color=GRY, lw=0.8))

# ─── Panel 3: EMC Revenue Trend ───
ax3 = fig.add_subplot(4, 3, 3)
ax3.fill_between(emc_years, emc_revenue, alpha=0.15, color=GOLD)
ax3.plot(emc_years, emc_revenue, "o-", color=GOLD, linewidth=2.5, markersize=7, label="Revenue ($bn)")
ax3b = ax3.twinx()
ax3b.plot(emc_years, emc_ni, "s--", color=DB, linewidth=2, markersize=6, label="Net Income ($bn)")
ax3b.spines["top"].set_visible(False)
ax3.set_title("EMC Pre-Deal Revenue & Net Income Trend", fontweight="bold", color=DB, pad=8)
ax3.set_ylabel("Revenue ($bn)", fontsize=9, color=GOLD)
ax3b.set_ylabel("Net Income ($bn)", fontsize=9, color=DB)
lines1, lbs1 = ax3.get_legend_handles_labels()
lines2, lbs2 = ax3b.get_legend_handles_labels()
ax3.legend(lines1+lines2, lbs1+lbs2, fontsize=8, loc="upper left")
for x, y in zip(emc_years, emc_revenue):
    ax3.annotate(f"${y:.1f}", (x, y), textcoords="offset points", xytext=(0, 8), ha="center", fontsize=8)
ax3.axvspan(2014.5, 2015.5, alpha=0.15, color=RED, label="Deal year")
ax3.text(2015, 17.5, "Deal\nAnnounced", fontsize=7.5, color=RED, ha="center")

# ─── Panel 4: SOTP Breakdown ───
ax4 = fig.add_subplot(4, 3, 4)
positive_s = [(v, l, c) for v, l, c in zip(sotp_values, sotp_labels, sotp_colors) if v >= 0]
negative_s = [(v, l, c) for v, l, c in zip(sotp_values, sotp_labels, sotp_colors) if v < 0]
pos_vals = [s[0] for s in positive_s]
pos_lbls = [s[1] for s in positive_s]
pos_cols = [s[2] for s in positive_s]
bars4 = ax4.barh(pos_lbls, pos_vals, color=pos_cols, edgecolor="white", linewidth=0.8)
ax4.set_title("SOTP Valuation — Breakdown ($bn)", fontweight="bold", color=DB, pad=8)
ax4.set_xlabel("Value ($bn)", fontsize=9)
total_sotp = sum(sotp_values)
ax4.axvline(total_sotp, color=DB, linestyle="--", linewidth=1.5, label=f"SOTP Total: ${total_sotp:.1f}bn")
ax4.axvline(67, color=RED, linestyle=":", linewidth=1.5, label="Deal Price: $67bn")
ax4.legend(fontsize=8)
for bar in bars4:
    ax4.text(bar.get_width()+0.3, bar.get_y()+bar.get_height()/2,
             f"${bar.get_width():.1f}bn", va="center", fontsize=8)

# ─── Panel 5: Deal Financing Pie ───
ax5 = fig.add_subplot(4, 3, 5)
wedge_props = dict(width=0.5, edgecolor="white", linewidth=2)
wedges, texts, autotexts = ax5.pie(
    fin_values, labels=fin_labels, colors=fin_colors, autopct="%1.1f%%",
    pctdistance=0.75, startangle=90, wedgeprops=wedge_props
)
for t in texts: t.set_fontsize(8)
for at in autotexts: at.set_fontsize(8); at.set_color("white"); at.set_fontweight("bold")
ax5.set_title(f"Deal Financing Structure\n(Total: $67bn)", fontweight="bold", color=DB, pad=8)
ax5.text(0, 0, f"$67bn", ha="center", va="center", fontsize=13, fontweight="bold", color=DB)

# ─── Panel 6: Precedent Transaction Bubble ───
ax6 = fig.add_subplot(4, 3, 6)
bubble_colors = [RED if n.startswith("Dell") else MB for n in prec_names]
scatter = ax6.scatter(
    prec_ev_rev, prec_premium,
    s=[d*6 for d in prec_sizes],
    c=bubble_colors, alpha=0.7, edgecolors=DB, linewidths=1.5
)
for i, name in enumerate(prec_names):
    ax6.annotate(name, (prec_ev_rev[i], prec_premium[i]),
                 textcoords="offset points", xytext=(5, 5), fontsize=7.5)
ax6.set_title("Precedent Transactions\n(Bubble = Deal Size)", fontweight="bold", color=DB, pad=8)
ax6.set_xlabel("EV / LTM Revenue Multiple", fontsize=9)
ax6.set_ylabel("Acquisition Premium (%)", fontsize=9)
ax6.yaxis.set_major_formatter(mticker.PercentFormatter())
ax6.set_xticklabels([f"{v:.0f}x" for v in ax6.get_xticks()], fontsize=8)
dell_patch = mpatches.Patch(color=RED, label="Dell/EMC (this deal)")
peer_patch  = mpatches.Patch(color=MB, label="Peer transactions")
ax6.legend(handles=[dell_patch, peer_patch], fontsize=8)

# ─── Panel 7: Post-Merger Revenue ───
ax7 = fig.add_subplot(4, 3, 7)
x7 = np.arange(len(post_fy))
b7a = ax7.bar(x7, post_rev,  width=0.5, color=DB, label="Total Revenue", edgecolor="white")
b7b = ax7.bar(x7, post_ent, width=0.5, color=GOLD, alpha=0.8, label="Enterprise ISG Revenue", edgecolor="white")
ax7.set_xticks(x7); ax7.set_xticklabels(post_fy, fontsize=7.5)
ax7.set_title("Dell Technologies Revenue\nPost-Acquisition ($bn)", fontweight="bold", color=DB, pad=8)
ax7.set_ylabel("Revenue ($bn)", fontsize=9)
ax7.legend(fontsize=8)
ax7.axvspan(-0.4, 0.4, alpha=0.08, color=GRN, label="Deal close year")
for bar in b7a:
    ax7.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.5,
             f"${bar.get_height():.0f}", ha="center", va="bottom", fontsize=7.5, color=DB)
ax7.annotate("VMware\nSpin-off\n2021", xy=(6, 101), xytext=(4.8, 92),
             arrowprops=dict(arrowstyle="->", color=RED, lw=1.2), fontsize=7.5, color=RED, ha="center")

# ─── Panel 8: Debt Paydown ───
ax8 = fig.add_subplot(4, 3, 8)
ax8.fill_between(range(len(post_fy)), post_debt, alpha=0.2, color=RED)
ax8.plot(range(len(post_fy)), post_debt, "o-", color=RED, linewidth=2.5, markersize=8)
ax8.set_xticks(range(len(post_fy))); ax8.set_xticklabels(post_fy, fontsize=7.5)
ax8.set_title("Dell Technologies Total Debt Reduction ($bn)", fontweight="bold", color=DB, pad=8)
ax8.set_ylabel("Total Debt ($bn)", fontsize=9)
ax8.set_ylim(0, 60)
debt_paiddown = post_debt[0] - post_debt[-1]
for i, (x, y) in enumerate(zip(range(len(post_fy)), post_debt)):
    ax8.annotate(f"${y:.0f}bn", (x, y), textcoords="offset points",
                 xytext=(0, 8), ha="center", fontsize=8, color=RED, fontweight="bold")
ax8.text(3, 55, f"Total paydown:\n${debt_paiddown:.0f}bn over 6 years",
         ha="center", fontsize=9, color=GRN, fontweight="bold",
         bbox=dict(boxstyle="round,pad=0.4", facecolor="#E8F5E9", edgecolor=GRN, linewidth=1.2))
ax8.annotate("VMware spin:\n$12bn dividend\naccelerates paydown",
             xy=(6, 22), xytext=(4, 15), fontsize=7.5, color=RED,
             arrowprops=dict(arrowstyle="->", color=RED, lw=1.0))

# ─── Panel 9: Integration Scorecard ───
ax9 = fig.add_subplot(4, 3, 9)
y9 = np.arange(len(score_dims))
b9 = ax9.barh(y9, score_vals, color=score_colors, edgecolor="white", linewidth=0.8)
ax9.set_yticks(y9); ax9.set_yticklabels(score_dims, fontsize=8.5)
ax9.set_xlim(0, 6)
ax9.axvline(4.0, color=GRN, linestyle="--", linewidth=1.2, alpha=0.7, label="Target (4/5)")
ax9.set_title("Integration Scorecard (1–5 Scale)", fontweight="bold", color=DB, pad=8)
ax9.set_xlabel("Score", fontsize=9)
for bar, score in zip(b9, score_vals):
    lbl = "✅" if score >= 4 else "⚠️"
    ax9.text(score+0.05, bar.get_y()+bar.get_height()/2,
             f"{lbl} {score:.0f}/5", va="center", fontsize=8.5)
avg_score = np.mean(score_vals)
ax9.text(5.8, len(score_dims)-1.2, f"Avg:\n{avg_score:.1f}/5",
         ha="center", fontsize=9, fontweight="bold", color=GRN,
         bbox=dict(boxstyle="round,pad=0.3", facecolor=LGY, edgecolor=GRN, linewidth=1))

# ─── Bottom Row: Deal Structure Table as Text Panel ───
ax10 = fig.add_subplot(4, 1, 4)
ax10.axis("off")
ax10.set_title("Deal Structure Summary & Key Valuation Metrics", fontweight="bold", color=DB, fontsize=12, pad=10)

table_data = [
    ["Total Deal Value", "$67.0 billion", "EV/Revenue Multiple", "2.7x", "Combined Revenue (PF)", "$74bn"],
    ["Cash per Share", "$24.05",          "EV/EBITDA Multiple", "12.2x","Acquisition Premium",  "~28%"],
    ["Tracking Stock per Share", "0.11146 DVMT", "SOTP Value (calc)", "~$63.5bn", "Strategic Premium", "~$3–5bn above SOTP"],
    ["Post-Close Debt", "~$50 billion",  "VMware Value (80%)", "~$40bn", "Year-1 Debt Paydown", "$9.6bn"],
    ["Financing Type", "LBO (leveraged)","EMC ex-VMware EV/Rev","~1.4x","Deal Closed",          "September 7, 2016"],
]

t = ax10.table(
    cellText=table_data,
    colLabels=["Item", "Value", "Multiple/Metric", "Figure", "Outcome Metric", "Figure"],
    cellLoc="center", loc="center", bbox=[0, 0, 1, 0.92]
)
t.auto_set_font_size(False); t.set_fontsize(10)
for (row, col), cell in t.get_celld().items():
    cell.set_edgecolor("#CCCCCC")
    if row == 0:
        cell.set_facecolor(DB)
        cell.set_text_props(color="white", fontweight="bold")
    elif row % 2 == 0:
        cell.set_facecolor(LGY)
    else:
        cell.set_facecolor("white")
    if col in [0, 2, 4] and row > 0:
        cell.set_text_props(fontweight="bold", color=DB)

plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig("/home/claude/dell_emc_case_study_charts.png", dpi=150, bbox_inches="tight",
            facecolor="white", edgecolor="none")
print("Charts saved.")

# ─────────────────────────────────────────────────────
# PRINT ANALYTICAL SUMMARY
# ─────────────────────────────────────────────────────
print("\n" + "="*72)
print("  DELL / EMC M&A CASE STUDY — KEY ANALYTICAL FINDINGS")
print("="*72)

print("\n📌 DEAL HEADLINE METRICS")
print(f"  Deal Value:           $67.0 billion (largest tech deal at the time)")
print(f"  Announcement:        October 12, 2015")
print(f"  Close Date:          September 7, 2016")
print(f"  Acquisition Premium: ~28% over pre-announcement price")
print(f"  EV/Revenue:          {67.0/24.7:.1f}x (EMC FY2015 Revenue: $24.7bn)")
print(f"  EV/EBITDA:           {67.0/5.5:.1f}x (EMC est. EBITDA: $5.5bn)")

print("\n📊 PRE-DEAL FINANCIAL COMPARISON (FY2015)")
print(f"  {'Metric':<25} {'Dell':>12} {'EMC':>12} {'Combined':>12}")
print(f"  {'─'*61}")
metrics_p = [("Revenue ($bn)", 54.1, 24.7), ("EBITDA ($bn)", 3.4, 5.5),
             ("Gross Margin", 0.175, 0.607), ("EBITDA Margin", 0.063, 0.223)]
for m, d, e in metrics_p:
    fmt = "{:>12.1%}" if "Margin" in m else "{:>12.1f}"
    dv = fmt.format(d)
    ev = fmt.format(e)
    cv = fmt.format(d+e) if "Margin" not in m else "{:>12}".format("blended")
    print(f"  {m:<25} {dv} {ev} {cv}")

print("\n💰 SOTP VALUATION BREAKDOWN")
print(f"  {'Component':<30} {'Value ($bn)':>12}")
print(f"  {'─'*43}")
for lbl, val in zip(sotp_labels, sotp_values):
    lbl_clean = lbl.replace('\n', ' ')
    print(f"  {lbl_clean:<30} {'${:>9.1f}bn'.format(val)}")
print(f"  {'─'*43}")
print(f"  {'TOTAL SOTP':<30} {'${:>9.1f}bn'.format(sum(sotp_values))}")
print(f"  {'Actual Deal Price':<30} {'$67.0bn':>12}")
print(f"  {'Strategic Premium':<30} {'${:>9.1f}bn'.format(67-sum(sotp_values))}")

print("\n📈 POST-MERGER PERFORMANCE")
print(f"  {'Fiscal Year':<30} {'Revenue':>10} {'Total Debt':>12}")
print(f"  {'─'*55}")
for fy, rev, debt in zip(post_fy, post_rev, post_debt):
    fy_clean = fy.replace('\n', '')
    print(f"  {fy_clean:<30} ${rev:>8.1f}bn  ${debt:>8.1f}bn")

print("\n📋 INTEGRATION SCORECARD")
for dim, score in zip(score_dims, score_vals):
    icon = "✅" if score >= 4 else "⚠️ "
    bar = "█" * score + "░" * (5-score)
    print(f"  {icon}  {dim:<30} [{bar}] {score}/5")
print(f"\n  Average Score: {np.mean(score_vals):.2f}/5.0 → Overall: SUCCESSFUL DEAL ✅")

print("\n" + "="*72)
print("  Analysis complete. Charts saved to: dell_emc_case_study_charts.png")
print("="*72)
